<?php

$classic = array(
    'image_size' => '718',
    'stylesheet' => 'classic.css'
);

?>