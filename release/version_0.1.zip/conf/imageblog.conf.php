<?php

$imageblog = array(
    'title'       => "Galdo's Blog",
    'data_path'   => "data",
    'date_format' => "Y-m-d",
    'template'    => "classic",
    
    //not to edit
);

?>